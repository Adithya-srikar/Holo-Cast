# ARCoreAgora

Find the step-by-step tutorial here: 
https://medium.com/@shaocheng.yang1995/how-to-build-an-augmented-reality-remote-assistance-app-in-android-ffde6406dff5
